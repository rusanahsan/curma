const rfNames=["Road Condition",
"Women Safety",
"Water Logging",
"Traffic Congestion",
"Freq gas stations"];
export default rfNames;